const webcam = document.getElementById("webcam");
const canvas = document.getElementById("snapshotCanvas");
const capturedImage = document.getElementById("capturedImage");
const captureBtn = document.getElementById("captureBtn");
const faceImageInput = document.getElementById("faceImageInput");

navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
        webcam.srcObject = stream;
    })
    .catch(err => {
        alert("Webcam access denied or not available.");
        console.error(err);
    });

captureBtn.addEventListener("click", () => {
    const context = canvas.getContext("2d");
    canvas.width = webcam.videoWidth;
    canvas.height = webcam.videoHeight;
    context.drawImage(webcam, 0, 0, canvas.width, canvas.height);

    // Get image data URL
    const imageData = canvas.toDataURL("image/png");

    // Display locally
    capturedImage.src = imageData;

    // Sendable (attach to hidden input)
    faceImageInput.value = imageData;
});

// Backend submission
document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch("your-backend-endpoint.php", {
            method: "POST",
            body: formData
        })
        .then(res => res.text())
        .then(data => {
            alert("Registration successful!");
            console.log(data);
        })
        .catch(err => {
            alert("Error during submission.");
            console.error(err);
        });
});