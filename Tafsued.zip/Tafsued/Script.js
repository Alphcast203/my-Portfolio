document.addEventListener("DOMContentLoaded", () => {
    const spans = document.querySelectorAll(".hero-subtitle .static-text");
    let current = 0;

    function showNextWord() {
        spans.forEach((span) => {
            span.style.color = "transparent"; // Hide all text
        });

        spans[current].style.color = "gold"; // Show current word
        current = (current + 1) % spans.length; // Move to next word
    }

    showNextWord(); // Start animation
    setInterval(showNextWord, 2000); // Change word every 2 seconds
});